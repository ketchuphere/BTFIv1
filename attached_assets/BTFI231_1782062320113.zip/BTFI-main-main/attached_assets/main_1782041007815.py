from datetime import datetime, timezone
from typing import Any, List, Literal, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from ml_service import get_ml_service
from optimizer import get_optimizer
from routing import get_diversion_planner

app = FastAPI(
    title='BTFI - Bengaluru Traffic Flow Intelligence',
    version='1.0.0',
    description='Traffic intelligence APIs for prediction, optimization, and diversion planning.',
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


class EventInput(BaseModel):
    event_type: str = Field(..., examples=['political_rally'])
    location: str = Field(..., examples=['MG Road Bangalore'])
    latitude: float = Field(..., examples=[12.9716])
    longitude: float = Field(..., examples=[77.5946])
    duration_minutes: int = Field(..., examples=[180])
    road_category: str = Field(..., examples=['major'])
    crowd_size: int = Field(..., examples=[5000])
    requires_road_closure: bool = Field(..., examples=[True])
    priority: str = Field(..., examples=['High'])


class CongestionInput(BaseModel):
    impact_score: float = Field(..., examples=[92])
    event_type: str = Field(..., examples=['political_rally'])
    location: str = Field(..., examples=['MG Road'])


class ResourceInput(BaseModel):
    impact_score: float = Field(..., examples=[92])
    congestion_level: str = Field(..., examples=['Critical'])
    queue_length: int = Field(..., examples=[5800])
    event_type: str = Field(..., examples=['political_rally'])


class DiversionInput(BaseModel):
    affected_road: str = Field(..., examples=['MG Road'])
    latitude: float = Field(..., examples=[12.9716])
    longitude: float = Field(..., examples=[77.5946])
    routing_provider: str = Field(default='mappls', examples=['mappls'])


class ImpactPrediction(BaseModel):
    impact_score: float
    risk_level: str
    confidence: float


class ImpactResponse(BaseModel):
    success: bool
    model: str
    prediction: ImpactPrediction
    timestamp: datetime


class CongestionPrediction(BaseModel):
    delay_30_minutes: float
    delay_60_minutes: float
    queue_length: int
    congestion_level: str


class CongestionResponse(BaseModel):
    success: bool
    model: str
    prediction: CongestionPrediction
    timestamp: datetime


class ResourceDeployment(BaseModel):
    police_required: int
    traffic_marshals: int
    barricades: int


class ResourceResponse(BaseModel):
    success: bool
    optimizer: str
    deployment: ResourceDeployment
    timestamp: datetime


class DiversionDetails(BaseModel):
    affected_road: str
    closure_required: bool
    primary_route: str
    secondary_route: str
    estimated_time: str


class DiversionResponse(BaseModel):
    success: bool
    routing_provider: str
    diversion: DiversionDetails
    timestamp: datetime


@app.get('/health')
def health():
    return {'status': 'healthy', 'service': 'BTFI', 'timestamp': datetime.now(timezone.utc)}


@app.get('/')
def root():
    return {
        'project': 'Bengaluru Traffic Flow Intelligence',
        'docs': '/docs',
        'health': '/health',
    }


@app.post('/api/predict-impact', response_model=ImpactResponse)
def predict_impact(event: EventInput):
    service = get_ml_service()
    result = service.predict_impact(event.model_dump())
    return {
        'success': True,
        'model': 'RandomForestRegressor',
        'prediction': {
            'impact_score': result.get('impact_score', 0.0),
            'risk_level': result.get('risk_level', 'Low'),
            'confidence': result.get('confidence', 0.92),
        },
        'timestamp': datetime.now(timezone.utc),
    }


@app.post('/api/predict-congestion', response_model=CongestionResponse)
def predict_congestion(data: CongestionInput):
    service = get_ml_service()
    result = service.predict_congestion(data.model_dump())
    return {
        'success': True,
        'model': 'XGBoost',
        'prediction': {
            'delay_30_minutes': result.get('delay_30_min', 0.0),
            'delay_60_minutes': result.get('delay_60_min', 0.0),
            'queue_length': result.get('queue_30_min', 0),
            'congestion_level': result.get('congestion_level_30', 'Low'),
        },
        'timestamp': datetime.now(timezone.utc),
    }


@app.post('/api/optimize-resources', response_model=ResourceResponse)
def optimize_resources(data: ResourceInput):
    optimizer = get_optimizer()
    result = optimizer.optimize_deployment(data.model_dump())
    deployment = result.get('optimization', {})
    return {
        'success': True,
        'optimizer': deployment.get('optimization_method', 'ILP'),
        'deployment': {
            'police_required': deployment.get('police_required', 0),
            'traffic_marshals': deployment.get('marshals_required', 0),
            'barricades': deployment.get('barricade_length_meters', 0),
        },
        'timestamp': datetime.now(timezone.utc),
    }


@app.post('/api/generate-diversion', response_model=DiversionResponse)
def generate_diversion(data: DiversionInput):
    planner = get_diversion_planner()
    result = planner.plan_diversion(
        (data.latitude, data.longitude),
        data.affected_road,
        {'routing_provider': data.routing_provider},
    )
    plan = result.get('diversion_plan', {})
    primary = plan.get('primary_route', {})
    alternatives: List[dict[str, Any]] = plan.get('alternative_routes', [])
    secondary_route = alternatives[0].get('route_description', 'Alternative Route B') if alternatives else 'Alternative Route B'
    return {
        'success': True,
        'routing_provider': plan.get('routing_provider', data.routing_provider),
        'diversion': {
            'affected_road': plan.get('affected_road', data.affected_road),
            'closure_required': bool(plan.get('closure_required', True)),
            'primary_route': primary.get('route_description', 'Alternative Corridor A'),
            'secondary_route': secondary_route,
            'estimated_time': f"{primary.get('duration_minutes', 15)} minutes",
        },
        'timestamp': datetime.now(timezone.utc),
    }


@app.post('/api/generate-report')
def generate_report(event_id: str, predictions: dict):
    report = f"""# BTFI Operational Report

Event ID: {event_id}
Impact Score: {predictions.get('impact_score')}
Congestion: {predictions.get('congestion_level')}
Generated: {datetime.now(timezone.utc)}
"""
    return {'success': True, 'file': f'BTFI_{event_id}.md', 'content': report}

