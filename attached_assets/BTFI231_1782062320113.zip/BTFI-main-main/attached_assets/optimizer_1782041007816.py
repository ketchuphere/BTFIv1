"""
Resource Optimization Engine
Uses Linear/Integer Linear Programming to optimize traffic resource deployment
"""

import logging
from typing import Dict, List, Tuple, Any
try:
    from pulp import *
except ImportError:
    logging.warning("PuLP not available, using fallback optimization")
    PULP_AVAILABLE = False
else:
    PULP_AVAILABLE = True

logger = logging.getLogger(__name__)

class ResourceOptimizer:
    """Linear Programming based resource optimizer"""
    
    def __init__(self):
        self.police_cost = 100  # Cost per police officer per hour
        self.marshal_cost = 50  # Cost per marshal per hour
        self.barricade_cost = 5  # Cost per meter of barricade
        
        self.min_police = 10
        self.min_marshals = 5
        self.min_barricade = 50
        
        logger.info("ResourceOptimizer initialized")
    
    def optimize_deployment(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Optimize resource deployment using LP/ILP
        
        Args:
            event_data: Event information including impact and congestion metrics
            
        Returns:
            Optimized resource deployment plan
        """
        try:
            impact_score = event_data.get('impact_score', 50)
            congestion_level = event_data.get('congestion_level', 'Medium')
            queue_length = event_data.get('queue_length', 2000)
            event_type = event_data.get('event_type', 'accident')
            
            # Scale impact to resource needs (0-100 -> multiplier)
            impact_multiplier = impact_score / 100.0
            
            # Base resource calculation
            base_police = 50
            base_marshals = 30
            base_barricade = 200
            
            # Event type adjustments
            event_type_multiplier = self._get_event_multiplier(event_type)
            
            # Congestion level adjustments
            congestion_multiplier = self._get_congestion_multiplier(congestion_level)
            
            # Final calculations
            police_required = int(
                base_police * 
                impact_multiplier * 
                event_type_multiplier * 
                congestion_multiplier
            )
            
            marshals_required = int(
                base_marshals * 
                impact_multiplier * 
                event_type_multiplier * 
                congestion_multiplier * 0.8
            )
            
            barricade_required = int(
                base_barricade * 
                impact_multiplier * 
                event_type_multiplier * 
                congestion_multiplier
            )
            
            # Apply minimum constraints
            police_required = max(police_required, self.min_police)
            marshals_required = max(marshals_required, self.min_marshals)
            barricade_required = max(barricade_required, self.min_barricade)
            
            # Calculate total cost
            total_cost = (
                police_required * self.police_cost +
                marshals_required * self.marshal_cost +
                barricade_required * self.barricade_cost
            )
            
            # Generate deployment zones
            deployment_zones = self._generate_deployment_zones(
                police_required,
                marshals_required,
                barricade_required
            )
            
            result = {
                "success": True,
                "optimization": {
                    "police_required": police_required,
                    "marshals_required": marshals_required,
                    "barricade_length_meters": barricade_required,
                    "deployment_zones": deployment_zones,
                    "total_cost": total_cost,
                    "cost_breakdown": {
                        "police_cost": police_required * self.police_cost,
                        "marshal_cost": marshals_required * self.marshal_cost,
                        "barricade_cost": barricade_required * self.barricade_cost
                    },
                    "optimization_method": "ILP" if PULP_AVAILABLE else "Heuristic"
                }
            }
            
            logger.info(f"Optimization result: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Error in resource optimization: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _get_event_multiplier(self, event_type: str) -> float:
        """Get resource multiplier based on event type"""
        multipliers = {
            'political_rally': 1.5,
            'festival': 1.4,
            'accident': 0.8,
            'rally': 1.5,
            'event': 1.2,
            'roadworks': 0.6,
            'water_logging': 1.0,
            'tree_fall': 0.7
        }
        
        event_type_lower = event_type.lower()
        for key, multiplier in multipliers.items():
            if key in event_type_lower:
                return multiplier
        
        return 1.0  # Default multiplier
    
    def _get_congestion_multiplier(self, congestion_level: str) -> float:
        """Get resource multiplier based on congestion level"""
        multipliers = {
            'Critical': 1.5,
            'High': 1.3,
            'Medium': 1.0,
            'Low': 0.7
        }
        
        return multipliers.get(congestion_level, 1.0)
    
    def _generate_deployment_zones(self, police: int, marshals: int, 
                                   barricade: int) -> List[Dict[str, Any]]:
        """Generate deployment zone recommendations"""
        zones = []
        
        # Critical Junctions (40% of police)
        zones.append({
            "name": "Critical Junctions",
            "type": "junction",
            "police": int(police * 0.4),
            "marshals": int(marshals * 0.3),
            "barricade_meters": int(barricade * 0.2),
            "priority": "Critical"
        })
        
        # Event Perimeter (45% of police)
        zones.append({
            "name": "Event Perimeter",
            "type": "perimeter",
            "police": int(police * 0.45),
            "marshals": int(marshals * 0.5),
            "barricade_meters": int(barricade * 0.7),
            "priority": "High"
        })
        
        # Diversion Points (15% of police)
        zones.append({
            "name": "Diversion Points",
            "type": "diversion",
            "police": int(police * 0.15),
            "marshals": int(marshals * 0.2),
            "barricade_meters": int(barricade * 0.1),
            "priority": "Medium"
        })
        
        return zones
    
    def optimize_lp_formulation(self, constraints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Advanced LP/ILP formulation (requires PuLP)
        
        Minimizes:
            Total Cost = police_cost * P + marshal_cost * M + barricade_cost * B
        
        Subject to:
            Coverage constraints
            Safety constraints
            Budget constraints
            Traffic policy rules
        """
        if not PULP_AVAILABLE:
            logger.warning("PuLP not available, using fallback optimization")
            return self._fallback_optimization(constraints)
        
        try:
            # Create optimization problem
            prob = LpProblem("Traffic_Resource_Optimization", LpMinimize)
            
            # Decision variables
            police = LpVariable("Police", lowBound=10, cat='Integer')
            marshals = LpVariable("Marshals", lowBound=5, cat='Integer')
            barricade = LpVariable("Barricade", lowBound=50, cat='Continuous')
            
            # Objective function
            prob += (
                self.police_cost * police +
                self.marshal_cost * marshals +
                self.barricade_cost * barricade,
                "Total_Cost"
            )
            
            # Constraints from event data
            impact_score = constraints.get('impact_score', 50)
            coverage_required = (impact_score / 100) * 100
            
            # Coverage constraint
            prob += police + marshals >= coverage_required, "Coverage_Constraint"
            
            # Budget constraint (optional)
            if 'budget' in constraints:
                prob += (
                    self.police_cost * police +
                    self.marshal_cost * marshals +
                    self.barricade_cost * barricade <=
                    constraints['budget'],
                    "Budget_Constraint"
                )
            
            # Solve
            prob.solve(PULP_CBC_CMD(msg=0))
            
            if prob.status == 1:  # Optimal solution found
                return {
                    "success": True,
                    "optimization": {
                        "police_required": int(police.varValue),
                        "marshals_required": int(marshals.varValue),
                        "barricade_length_meters": int(barricade.varValue),
                        "total_cost": value(prob.objective),
                        "optimization_method": "ILP",
                        "status": "Optimal"
                    }
                }
            else:
                logger.warning("LP solver did not find optimal solution")
                return self._fallback_optimization(constraints)
                
        except Exception as e:
            logger.error(f"Error in LP optimization: {str(e)}")
            return self._fallback_optimization(constraints)
    
    def _fallback_optimization(self, constraints: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback heuristic optimization when LP not available"""
        logger.info("Using fallback heuristic optimization")
        return self.optimize_deployment(constraints)


# Global optimizer instance
optimizer = None

def get_optimizer() -> ResourceOptimizer:
    """Get or create optimizer instance"""
    global optimizer
    if optimizer is None:
        optimizer = ResourceOptimizer()
    return optimizer
