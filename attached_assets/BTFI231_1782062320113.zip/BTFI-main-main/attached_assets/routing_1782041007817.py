"""
Routing Provider Abstraction Layer
Supports multiple routing providers: Mappls, OpenStreetMap, Telematics
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Optional, Any
import os

logger = logging.getLogger(__name__)

class RoutingProvider(ABC):
    """Abstract base class for routing providers"""
    
    @abstractmethod
    def get_route(self, origin: Tuple[float, float], 
                  destination: Tuple[float, float]) -> Dict[str, Any]:
        """Get primary route between two points"""
        pass
    
    @abstractmethod
    def get_alternative_routes(self, origin: Tuple[float, float],
                               destination: Tuple[float, float],
                               num_routes: int = 3) -> List[Dict[str, Any]]:
        """Get alternative routes"""
        pass
    
    @abstractmethod
    def get_distance_matrix(self, origins: List[Tuple[float, float]],
                            destinations: List[Tuple[float, float]]) -> Dict[str, Any]:
        """Get distance/time matrix between multiple points"""
        pass
    
    @abstractmethod
    def snap_to_road(self, latitude: float, longitude: float) -> Dict[str, Any]:
        """Snap GPS coordinates to nearest road"""
        pass


class MapplsProvider(RoutingProvider):
    """Mappls / MapmyIndia routing provider"""
    
    def __init__(self, client_id: str = None, client_secret: str = None):
        self.client_id = client_id or os.getenv('MAPPLS_CLIENT_ID', '')
        self.client_secret = client_secret or os.getenv('MAPPLS_CLIENT_SECRET', '')
        self.api_key = os.getenv('MAPPLS_STATIC_KEY', '')
        self.base_url = "https://apis.mappls.com"
        
        if not self.api_key:
            logger.warning("Mappls API key not configured")
    
    def get_route(self, origin: Tuple[float, float],
                  destination: Tuple[float, float]) -> Dict[str, Any]:
        """Get route using Mappls API"""
        try:
            # In production, call actual Mappls API
            # For now, return mock response
            return {
                "success": True,
                "provider": "Mappls",
                "origin": origin,
                "destination": destination,
                "distance_km": 12.5,
                "duration_minutes": 25,
                "route_points": [
                    {"lat": origin[0], "lng": origin[1]},
                    {"lat": (origin[0] + destination[0]) / 2, 
                     "lng": (origin[1] + destination[1]) / 2},
                    {"lat": destination[0], "lng": destination[1]}
                ]
            }
        except Exception as e:
            logger.error(f"Error getting Mappls route: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_alternative_routes(self, origin: Tuple[float, float],
                               destination: Tuple[float, float],
                               num_routes: int = 3) -> List[Dict[str, Any]]:
        """Get alternative routes from Mappls"""
        routes = []
        for i in range(num_routes):
            routes.append({
                "route_id": i + 1,
                "provider": "Mappls",
                "distance_km": 12.5 + (i * 2),
                "duration_minutes": 25 + (i * 5),
                "route_description": f"Route {chr(65 + i)}"
            })
        return routes
    
    def get_distance_matrix(self, origins: List[Tuple[float, float]],
                            destinations: List[Tuple[float, float]]) -> Dict[str, Any]:
        """Get distance matrix from Mappls"""
        # Mock response
        matrix = []
        for origin in origins:
            row = []
            for destination in destinations:
                row.append({
                    "distance_km": 10.0,
                    "duration_minutes": 20.0
                })
            matrix.append(row)
        return {"matrix": matrix, "provider": "Mappls"}
    
    def snap_to_road(self, latitude: float, longitude: float) -> Dict[str, Any]:
        """Snap to road using Mappls"""
        return {
            "success": True,
            "provider": "Mappls",
            "snapped_lat": latitude,
            "snapped_lng": longitude,
            "road_name": "MG Road"
        }


class OpenStreetMapProvider(RoutingProvider):
    """OpenStreetMap/OSRM routing provider"""
    
    def __init__(self):
        self.base_url = "https://router.project-osrm.org"
        logger.info("OpenStreetMap provider initialized")
    
    def get_route(self, origin: Tuple[float, float],
                  destination: Tuple[float, float]) -> Dict[str, Any]:
        """Get route using OSRM"""
        try:
            # OSRM coordinates are lng,lat
            coords = f"{origin[1]},{origin[0]};{destination[1]},{destination[0]}"
            
            # Mock response for demo
            return {
                "success": True,
                "provider": "OpenStreetMap",
                "origin": origin,
                "destination": destination,
                "distance_km": 12.5,
                "duration_minutes": 25,
                "route_points": [
                    {"lat": origin[0], "lng": origin[1]},
                    {"lat": destination[0], "lng": destination[1]}
                ]
            }
        except Exception as e:
            logger.error(f"Error getting OSM route: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_alternative_routes(self, origin: Tuple[float, float],
                               destination: Tuple[float, float],
                               num_routes: int = 3) -> List[Dict[str, Any]]:
        """Get alternative routes from OSRM"""
        routes = []
        for i in range(min(num_routes, 2)):  # OSRM usually provides 1-2 alternatives
            routes.append({
                "route_id": i + 1,
                "provider": "OpenStreetMap",
                "distance_km": 12.5 + (i * 1.5),
                "duration_minutes": 25 + (i * 3),
                "route_description": f"Alternative Route {i + 1}"
            })
        return routes
    
    def get_distance_matrix(self, origins: List[Tuple[float, float]],
                            destinations: List[Tuple[float, float]]) -> Dict[str, Any]:
        """Get distance matrix from OSRM"""
        # Mock response
        matrix = []
        for origin in origins:
            row = []
            for destination in destinations:
                row.append({
                    "distance_km": 8.0,
                    "duration_minutes": 15.0
                })
            matrix.append(row)
        return {"matrix": matrix, "provider": "OpenStreetMap"}
    
    def snap_to_road(self, latitude: float, longitude: float) -> Dict[str, Any]:
        """Snap to road using OSRM"""
        return {
            "success": True,
            "provider": "OpenStreetMap",
            "snapped_lat": latitude,
            "snapped_lng": longitude,
            "road_name": "Approximate Road"
        }


class RoutingProviderFactory:
    """Factory for creating routing providers"""
    
    providers = {
        "mappls": MapplsProvider,
        "openstreetmap": OpenStreetMapProvider,
        "osm": OpenStreetMapProvider
    }
    
    @classmethod
    def create_provider(cls, provider_name: str = None) -> RoutingProvider:
        """Create routing provider instance"""
        if provider_name is None:
            provider_name = os.getenv('ROUTING_PROVIDER', 'openstreetmap')
        
        provider_name = provider_name.lower()
        
        if provider_name in cls.providers:
            logger.info(f"Creating {provider_name} routing provider")
            return cls.providers[provider_name]()
        else:
            logger.warning(f"Unknown provider: {provider_name}, using OpenStreetMap")
            return OpenStreetMapProvider()


class DiversionPlanner:
    """Generates diversion plans using routing providers"""
    
    def __init__(self, provider: RoutingProvider = None):
        self.provider = provider or RoutingProviderFactory.create_provider()
        logger.info(f"DiversionPlanner initialized with {type(self.provider).__name__}")
    
    def plan_diversion(self, event_location: Tuple[float, float],
                      affected_road: str,
                      event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Plan diversion for affected road
        
        Args:
            event_location: Tuple of (latitude, longitude)
            affected_road: Name of affected road
            event_data: Additional event information
            
        Returns:
            Diversion plan with alternative routes
        """
        try:
            # Define common diversion endpoints (simplified for Bengaluru)
            alternate_destinations = [
                (13.0000, 77.5800),  # Alternate route 1
                (13.0100, 77.5900),  # Alternate route 2
                (12.9900, 77.6000),  # Alternate route 3
            ]
            
            primary_route = self.provider.get_route(
                event_location,
                alternate_destinations[0]
            )
            
            alternative_routes = self.provider.get_alternative_routes(
                event_location,
                alternate_destinations[0],
                num_routes=2
            )
            
            return {
                "success": True,
                "diversion_plan": {
                    "affected_road": affected_road,
                    "closure_required": True,
                    "primary_route": primary_route,
                    "alternative_routes": alternative_routes,
                    "deployment_zones": [
                        "Closure start point",
                        "Alternative route start",
                        "Alternate route 2 start"
                    ],
                    "routing_provider": type(self.provider).__name__
                }
            }
            
        except Exception as e:
            logger.error(f"Error planning diversion: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }


# Global instances
_routing_provider = None
_diversion_planner = None

def get_routing_provider(provider_name: str = None) -> RoutingProvider:
    """Get or create routing provider"""
    global _routing_provider
    if _routing_provider is None:
        _routing_provider = RoutingProviderFactory.create_provider(provider_name)
    return _routing_provider

def get_diversion_planner() -> DiversionPlanner:
    """Get or create diversion planner"""
    global _diversion_planner
    if _diversion_planner is None:
        provider = get_routing_provider()
        _diversion_planner = DiversionPlanner(provider)
    return _diversion_planner
